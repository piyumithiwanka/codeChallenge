import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Challenge {
private static JSONArray getJsonArray(String jsonFile){
		JSONArray jsonArray = null;
		//JsonParser to convert JSON string into Json Object
		JSONParser jsonParser = new JSONParser();
		try {
				//read the json file
				FileReader file = new FileReader(jsonFile + ".json"); 
				
				//parsing the JSON string inside the file
				Object obj = jsonParser.parse(file);
				
				//parsing the JSON string object to JSONArray
				 jsonArray = (JSONArray) obj;
		} catch (FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonArray;
	
}
	
public static void  getSearchableFields(){
	System.out.println("--------------------------------------------------------------");
	System.out.println("Search Users with");
	printFileds("users");
	System.out.println("--------------------------------------------------------------");
	System.out.println("Search Tickets with");
	printFileds("tickets");
	System.out.println("--------------------------------------------------------------");
	System.out.println("Search Organizations with");
	printFileds("organizations");	
}

@SuppressWarnings("unchecked")
public static void printFileds(String file){
	try {
		//parsing the JSONArray in the file
		JSONArray userArray = getJsonArray(file);		
	    //Iterator is used to access the each object in the list
		Iterator<JSONObject> iterator = userArray.iterator(); 
		//loop will continue once.
		while (iterator.hasNext()) {
			//accessing an object by using next function.
			JSONObject userObj =(JSONObject) iterator.next();
			  ///loop will continue as long as there are keys in the object key set.
			  for (Object key : userObj.keySet()) {
				  //print each key
		          System.out.println(key.toString());
		      }
			System.out.println();
			return;
		}
	} catch (Exception e) {
		e.printStackTrace();
	} 
}

public static void getOrgName(String orgId){
			try {
				//parsing the JSONArray in the file
				JSONArray orgArray = getJsonArray("organizations");
				//Iterator is used to access the each object in the list 
				Iterator<JSONObject> orgIterator = orgArray.iterator();  
				//loop will continue as long as there are objects in the array.
				while (orgIterator.hasNext()){
					//accessing each object by using next function.
					JSONObject orgObj =(JSONObject) orgIterator.next();
					// get the value of the key in each object 
					Object orgVal = (Object) orgObj.get("_id"); 
					//match the parameter value with the key value
					if(orgId.equals(orgVal != null ? orgVal.toString():null)){
						System.out.println(String.format("%-25s %s" , "organization_name" , orgObj.get("name")));            				
					}         			    	
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
 }

public static void getTktSubject(String orgId){
	try {
		//parsing the JSONArray in the file
		JSONArray tctArray = getJsonArray("tickets");
		//Iterator is used to access the each object in the list 
		Iterator<JSONObject> tctIterator = tctArray.iterator();  
		//loop will continue as long as there are objects in the array.
		int i = 0;
		while (tctIterator.hasNext()){
			//accessing each object by using next function.
			JSONObject tctObj =(JSONObject) tctIterator.next();
			// get the value of the key in each object 
			Object tctVal = (Object) tctObj.get("organization_id"); 
			//match the parameter value with the key value
			if(orgId.equals(tctVal != null ? tctVal.toString():null)){
				System.out.println(String.format("%-25s %s" ,"ticket_ " +i , tctObj.get("subject")));
				i+=1;
			}
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public static void getUserName(String asgnId, String subId){
	try {
		//parsing the JSONArray in the file
		JSONArray usrArray = getJsonArray("users");
		//Iterator is used to access the each object in the list 
		Iterator<JSONObject> usrIterator = usrArray.iterator();  
		//loop will continue as long as there are objects in the array.
		while (usrIterator.hasNext()){
		    	//accessing each object by using next function.
		    	JSONObject usrObj =(JSONObject) usrIterator.next();
		    	// get the value of the key in each object 
				Object orgVal = (Object) usrObj.get("_id"); 
				//match the parameter value with the key value
				if(asgnId.equals(orgVal != null ? orgVal.toString():null)){
					System.out.println(String.format("%-25s %s" , "assignee_name" , usrObj.get("name")));            				
				} 
				//match the parameter value with the key value
				if(subId.toString().equals(orgVal != null ? orgVal.toString():null)){
					System.out.println(String.format("%-25s %s" , "submitter_name" , usrObj.get("name")));            				
				} 
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public static void getOrgUsers(String orgId){
	try {
		//parsing the JSONArray in the file
		JSONArray usrArray = getJsonArray("users");
		//Iterator is used to access the each object in the list 
		Iterator<JSONObject> usrIterator = usrArray.iterator();  
		//loop will continue as long as there are objects in the array.
		int j = 0;
		while (usrIterator.hasNext()){
			//accessing each object by using next function.
			JSONObject tctObj =(JSONObject) usrIterator.next();
			// get the value of the key in each object 
			Object tctVal = (Object) tctObj.get("organization_id"); 
			//match the parameter value with the key value
			if(orgId.equals(tctVal != null ? tctVal.toString():null)){
				System.out.println(String.format("%-25s %s" ,"user_" +j , tctObj.get("name")));
				j+=1;
			}   		
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

@SuppressWarnings("unchecked")
private static void getSearchData(String key , String value , String file){
	Boolean found = false;
	//parsing the JSONArray in the file
	try {
		JSONArray userArray = getJsonArray(file);
		//Iterator is used to access the each object in the list 
		Iterator<JSONObject> iterator = userArray.iterator();  
		//loop will continue as long as there are objects in the array.
		while (iterator.hasNext()){
			//accessing each object by using next function.
			JSONObject searchObj =(JSONObject) iterator.next();
			// get the value of the key in each object 
			Object searchVal = (Object) searchObj.get(key); 
			//match the parameter value with the key value
			if(value.equals(searchVal != null ? searchVal.toString():null)){
			//Displaying values from JSON Object by using Keys
		    for (Object seartchKey : searchObj.keySet()) {
		    		if(!("_id".equals(seartchKey.toString()) || "url".equals(seartchKey.toString()))){
			          System.out.println(String.format("%-25s %s" , seartchKey.toString(), searchObj.get(seartchKey)));
			      }       	
		    }
		    if("users".equalsIgnoreCase(file)){
		    	 if(searchObj.get("organization_id") != null){
		    		 	getOrgName(searchObj.get("organization_id").toString());
		    		 	getTktSubject(searchObj.get("organization_id").toString());
		    	 }
		    }else if("tickets".equalsIgnoreCase(file)){
		    		String asgnId = searchObj.get("assignee_id")!= null ? searchObj.get("assignee_id").toString() :null;
		    		String subId  = searchObj.get("submitter_id")!= null ? searchObj.get("submitter_id").toString() :null;
		    		getUserName(asgnId,subId);
		    	 if(searchObj.get("organization_id") != null){
		 		 	getOrgName(searchObj.get("organization_id").toString());
		 	      }
		    }else if("organizations".equalsIgnoreCase(file)){
		    	if(searchObj.get("_id") != null){
		    		getTktSubject(searchObj.get("_id").toString());
		    		getOrgUsers(searchObj.get("_id").toString());
		    	}
		  	  	
		    }
		    found = true;
			return;
			}
		}  
		if(!found){
			System.out.println("Searching "+ file + " for " +key + " with a value of "+value);
			System.out.println("No results found");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public static void main(String[] args) {
	    try {
				// Using Scanner for Getting Input from User 
				@SuppressWarnings("resource")
				Scanner in = new Scanner(System.in); 
				System.out.println("Type 'quit' to exit at any time, Press 'Enter' to continue\n\n");
				System.out.println("\t\t Select search options:");
				System.out.println("\t\t * Press 1 to search");
				System.out.println("\t\t * Press 2 to view a list of searchable fields");
				System.out.println("\t\t * Type 'quit' to exit");
				//reading input
				String s1 = in.nextLine(); 
				if(s1.equals("quit"))
				    System.exit(0);
				else if(s1.equals("1")){
					System.out.println("Select 1)Users or 2)Tickets or 3)Organizations");
					String s2 = in.nextLine();
					if(s2.equals("quit"))
				        System.exit(0);
					else if(s2.equals("1")){
						System.out.println("Enter search term");
						String u1 = in.nextLine(); 
						System.out.println("Enter search value");
						String u2 = in.nextLine(); 
						getSearchData(u1,u2,"users");
					}else if(s2.equals("2")){
						System.out.println("Enter search term");
						String t1 = in.nextLine(); 
						System.out.println("Enter search value");
						String t2 = in.nextLine();
						getSearchData(t1,t2,"tickets");
					}else if(s2.equals("3")){
						System.out.println("Enter search term");
						String o1 = in.nextLine(); 
						System.out.println("Enter search value");
						String o2 = in.nextLine(); 
						getSearchData(o1,o2,"organizations");
					}else{
						System.out.println("Not a valid input.Please try again.");
						in.nextLine();
					}
				}else if(s1.equals("2")){
					getSearchableFields();
				}else{
					System.out.println("Not a valid input.Please try again.");
					in.nextLine();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	 
	}
}
